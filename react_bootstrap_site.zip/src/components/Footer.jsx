import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Footer() {
  return (
    <footer className="bg-dark text-light py-4 mt-auto">
      <div className="container d-flex flex-column flex-md-row justify-content-between align-items-center">
        <div>© {new Date().getFullYear()} My Website.</div>
        <div>
          <a href="#" className="text-light me-3 text-decoration-none">Privacy</a>
          <a href="#" className="text-light text-decoration-none">Terms</a>
        </div>
      </div>
    </footer>
  );
}