import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Hero({ title, subtitle, imageUrl, full = true }) {
  const heroHeight = full ? '100vh' : '50vh';
  const heroStyle = {
    height: heroHeight,
    backgroundImage: `url(${imageUrl})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    position: 'relative',
    color: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  };
  return (
    <header style={heroStyle}>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }}></div>
      <div className="text-center" style={{ position: 'relative', zIndex: 2 }}>
        <h1 className="display-4 fw-bold">{title}</h1>
        <p className="lead">{subtitle}</p>
      </div>
    </header>
  );
}