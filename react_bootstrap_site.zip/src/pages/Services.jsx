import React from 'react';
import Hero from '../components/Hero';

export default function Services() {
  return (
    <>
      <Hero title="Our Services" subtitle="What we offer." imageUrl="https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1600&q=60" full={true} />
      <section className="container py-5"><h2>Services Content</h2></section>
    </>
  );
}