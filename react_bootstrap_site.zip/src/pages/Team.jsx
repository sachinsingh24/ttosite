import React from 'react';
import Hero from '../components/Hero';

export default function Team() {
  return (
    <>
      <Hero title="Our Team" subtitle="Meet our team members." imageUrl="https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1600&q=60" full={true} />
      <section className="container py-5"><h2>Team Content</h2></section>
    </>
  );
}