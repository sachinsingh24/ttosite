import React from 'react';
import Hero from '../components/Hero';

export default function About() {
  return (
    <>
      <Hero title="About Us" subtitle="Learn more about who we are." imageUrl="https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1600&q=60" full={true} />
      <section className="container py-5"><h2>About Content</h2></section>
    </>
  );
}