import React from 'react';
import Hero from '../components/Hero';

export default function Home() {
  return (
    <>
      <Hero title="Home" subtitle="Welcome to our homepage." imageUrl="https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1600&q=60" full={true} />
      <section className="container py-5"><h2>Home Page Content</h2></section>
    </>
  );
}