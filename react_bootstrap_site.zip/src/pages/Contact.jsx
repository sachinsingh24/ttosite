import React from 'react';
import Hero from '../components/Hero';

export default function Contact() {
  return (
    <>
      <Hero title="Contact Us" subtitle="We'd love to hear from you." imageUrl="https://images.unsplash.com/photo-1533750349088-cd871a92f312?auto=format&fit=crop&w=1600&q=60" full={false} />
      <section className="container py-5"><h2>Contact Content</h2></section>
    </>
  );
}